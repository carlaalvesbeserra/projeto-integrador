namespace projeto_mf.Models
{
    public class CadastroPedido
    {
        public int Id {get; set;}
        public string Nome {get; set;}
        public int Telefone {get; set;}
        public string DataEntrega {get; set;}
        public string Pedido {get;set;}
        public int Quantidade {get; set;}
    }
}